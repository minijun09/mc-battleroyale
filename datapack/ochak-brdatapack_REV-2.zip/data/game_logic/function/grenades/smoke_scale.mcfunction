# 1. [핵심] 소환된 다음 틱에 애니메이션 데이터를 주입합니다.
# start_interpolation: 0은 '현재(0.01)부터 시작해라'는 뜻입니다.
execute as @e[tag=smoke_init] run data merge entity @s {block_state:{Name:"minecraft:light_gray_stained_glass"},scale:[1f,1f,1f],start_interpolation: 0}
# 2. 명령을 내렸으므로 'init' 태그를 지워 중복 실행을 막습니다.
tag @e[tag=smoke_init] remove smoke_init