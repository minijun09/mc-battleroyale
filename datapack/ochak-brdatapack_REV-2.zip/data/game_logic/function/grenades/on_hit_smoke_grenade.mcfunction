# 1. 아주 작은 크기(0.01)로 소환
# 초기 상태를 설정하여 소환합니다.
summon block_display ~2 ~4 ~2 {Tags:["smoke_cloud","smoke_init"],block_state:{Name:"minecraft:white_wool"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.01f,0.01f,0.01f]}}
# 2. 소리 효과 (치이익-)
playsound minecraft:block.lava.extinguish block @a ~ ~ ~ 1 0.5
kill @s