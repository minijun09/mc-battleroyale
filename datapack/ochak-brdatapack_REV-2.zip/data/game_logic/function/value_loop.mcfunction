scoreboard players add @a gun_use 0
scoreboard players add @a max_range 0
scoreboard players add @a revolver_cooldown 0
scoreboard players add @a max_ammo 0
scoreboard players add @a ammo 0
scoreboard players add @a revolver_use 0
scoreboard players add @a smoke_timer 0
scoreboard players add @e[tag=bullet] bullet_age 1
execute as @a if score @s revolver_cooldown matches 1.. run scoreboard players remove @s revolver_cooldown 1