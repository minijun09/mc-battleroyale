#사용 감지후 함수호출 & 변수 초기화
execute as @a[scores={gun_use=1..}] if items entity @s weapon.mainhand *[custom_data~{gun_id:"revolver"}] at @s run function game_logic:guns/revolver
execute as @a[scores={gun_use=1..}] at @s run scoreboard players set @s gun_use 0
scoreboard players add @e[tag=bullet] bullet_age 1
