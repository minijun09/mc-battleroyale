#총알 없으면 리턴
execute unless items entity @s container.* minecraft:copper_nugget[item_name={"text":".357 매그넘"}] run item replace entity @s weapon.mainhand from entity @s weapon.offhand
execute unless items entity @s container.* minecraft:copper_nugget[item_name={"text":".357 매그넘"}] run item replace entity @s weapon.offhand with air
execute unless items entity @s container.* minecraft:copper_nugget[item_name={"text":".357 매그넘"}] run return 1

#총알이 가득차있으면 리턴
execute if score @s ammo = @s max_ammo run item replace entity @s weapon.mainhand from entity @s weapon.offhand
execute if score @s ammo = @s max_ammo run item replace entity @s weapon.offhand with air
execute if score @s ammo = @s max_ammo run return 1

#쿨다운중이면 리턴
execute if score @s revolver_cooldown matches 1.. run item replace entity @s weapon.mainhand from entity @s weapon.offhand
execute if score @s revolver_cooldown matches 1.. run item replace entity @s weapon.offhand with air
execute if score @s revolver_cooldown matches 1.. run return 1

#재장전코드
execute as @s[scores={revolver_cooldown=0}] run scoreboard players add @s ammo 1
execute as @s[scores={revolver_cooldown=0}] store result storage game_logic:ammo value int 1 run scoreboard players get @s ammo
execute as @s[scores={revolver_cooldown=0}] run item replace entity @s weapon.mainhand from entity @s weapon.offhand
execute as @s[scores={revolver_cooldown=0}] run item modify entity @s weapon.mainhand game_logic:update_item
execute as @s[scores={revolver_cooldown=0}] run item replace entity @s weapon.offhand with air
execute as @s[scores={revolver_cooldown=0}] run clear @s minecraft:copper_nugget[item_name={"text":".357 매그넘"}] 1
execute as @s[scores={revolver_cooldown=0}] run scoreboard players set @s revolver_cooldown 10