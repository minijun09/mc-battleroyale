
#총알수 감지
execute as @a if items entity @s weapon.mainhand *[custom_data~{gun_id:revolver}] store result score @s ammo run data get entity @s SelectedItem.components."minecraft:custom_data".ammo
execute as @a if items entity @s weapon.mainhand *[custom_data~{gun_id:revolver}] store result score @s max_ammo run data get entity @s SelectedItem.components."minecraft:custom_data".max_ammo
execute as @a if items entity @s weapon.mainhand *[custom_data~{gun_id:revolver}] store result storage game_logic:ammo value int 1 run scoreboard players get @s ammo
execute as @a if items entity @s weapon.mainhand *[custom_data~{gun_id:revolver}] run item modify entity @s weapon.mainhand game_logic:update_item

#재장전
execute as @a if items entity @s weapon.offhand *[custom_data~{gun_id:"revolver"}] run function game_logic:main_logic/revolver_reload
