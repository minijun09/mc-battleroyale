execute as @s[scores={revolver_cooldown=0,ammo=1..}] run function game_logic:main_logic/revolver_use
execute as @s[scores={revolver_cooldown=0,ammo=1..}] run scoreboard players remove @s ammo 1 
execute as @s[scores={revolver_cooldown=0}] if items entity @s weapon.mainhand *[custom_data~{gun_id:revolver}] store result storage game_logic:ammo value int 1 run scoreboard players get @s ammo
execute as @s[scores={revolver_cooldown=0}] if items entity @s weapon.mainhand *[custom_data~{gun_id:revolver}] run item modify entity @s weapon.mainhand game_logic:update_item
execute as @s[scores={revolver_cooldown=0,ammo=1..}] run scoreboard players set @s revolver_cooldown 10