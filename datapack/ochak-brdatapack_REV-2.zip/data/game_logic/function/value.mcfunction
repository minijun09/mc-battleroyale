scoreboard objectives add gun_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add max_range dummy
scoreboard objectives add revolver_cooldown dummy
scoreboard objectives add bullet_age dummy
scoreboard objectives add ammo dummy
scoreboard objectives add max_ammo dummy
scoreboard objectives add revolver_use dummy
scoreboard objectives add smoke_timer dummy